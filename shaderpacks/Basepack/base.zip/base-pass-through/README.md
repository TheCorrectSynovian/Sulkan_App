# Base Pass-Through Shader Pack

This is a minimal Sulkan shader pack template.

It keeps the current Sulkan shader entrypoints, sampler bindings, uniform blocks, vertex inputs, and compile-time defines, but the visible rendering passes are reduced to straightforward pass-through shading.

## Use

1. Zip the contents of this folder.
2. Drop the resulting `.zip` into the Minecraft `shaders` folder.
3. Open `Video Settings -> Shaders` and select the pack.

This template uses the short supported layout:

- `shaders/core/...`

Sulkan will remap that to `assets/sulkan/shaders/...` when it loads the pack.

## Included shader entrypoints

- `shaders/core/shadow_depth` for terrain shadow caster passes
- `shaders/core/terrain_shadow` for terrain receiver passes
- `shaders/core/entity_shadow_depth` for entity shadow caster passes
- `shaders/core/entity_shadow` for entity receiver passes
- `shaders/core/water` for the water surface pass

## Notes

- The extra samplers, UBOs, and varyings are intentionally still declared even when the pass-through version does not use them yet.
- The template preserves Sulkan's current optional defines, including `ALPHA_CUTOUT`, `PER_FACE_LIGHTING`, `NO_OVERLAY`, `EMISSIVE`, and `DISSOLVE`.
- Start by editing one shader pair at a time.