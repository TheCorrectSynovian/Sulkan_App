#version 450 core

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chunksection.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

layout(binding = 2) uniform sampler2D Sampler2;

layout(std140, binding = 1) uniform WaveUniforms {
    vec4 WaveData;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
layout(location = 4) out vec3 worldPos;
layout(location = 5) out vec3 viewPos;
layout(location = 6) out vec3 waveNormal;
layout(location = 7) flat out float isWaterVertex;
layout(location = 8) out vec2 worldXZ;

void main() {
    bool waterVertex = (UV2.x & 1) != 0;

    vec3 pos = Position + vec3(ChunkPosition - CameraBlockPos) + CameraOffset;
    vec2 absoluteWorldXZ = Position.xz + vec2(ChunkPosition.xz);
    vec4 viewSpacePos = ModelViewMat * vec4(pos, 1.0);

    gl_Position = ProjMat * viewSpacePos;
    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = Color * sample_lightmap(Sampler2, ivec2(UV2.x & ~1, UV2.y));
    texCoord0 = UV0;
    worldPos = pos;
    viewPos = viewSpacePos.xyz;
    waveNormal = vec3(0.0, 1.0, 0.0);
    isWaterVertex = float(waterVertex);
    worldXZ = absoluteWorldXZ;
}