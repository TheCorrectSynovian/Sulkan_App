#version 450 core

#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chunksection.glsl>

layout(std140, binding = 0) uniform ShadowMatrices {
    mat4 ShadowProjViewMat;
    vec4 ShadowSunDir;
    vec4 ShadowParams;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV2;

#ifdef ALPHA_CUTOUT
layout(location = 0) out vec2 texCoord0;
#endif

void main() {
    vec3 pos = Position + vec3(ChunkPosition - CameraBlockPos) + CameraOffset;
    gl_Position = ShadowProjViewMat * vec4(pos, 1.0);

#ifdef ALPHA_CUTOUT
    texCoord0 = UV0;
#endif
}