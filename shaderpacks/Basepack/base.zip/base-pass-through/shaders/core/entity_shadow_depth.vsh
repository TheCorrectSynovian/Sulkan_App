#version 450 core

#moj_import <minecraft:dynamictransforms.glsl>

layout(std140, binding = 0) uniform EntityShadowMatrices {
    mat4 ShadowEntityMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;

#ifdef ALPHA_CUTOUT
layout(location = 0) out vec2 texCoord0;
#endif

void main() {
    gl_Position = ShadowEntityMat * (ModelViewMat * vec4(Position, 1.0));

#ifdef ALPHA_CUTOUT
    texCoord0 = UV0;
#endif
}