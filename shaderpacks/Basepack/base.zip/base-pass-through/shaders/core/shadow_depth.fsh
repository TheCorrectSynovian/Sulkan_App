#version 450 core

layout(std140, binding = 0) uniform ShadowMatrices {
    mat4 ShadowProjViewMat;
    vec4 ShadowSunDir;
    vec4 ShadowParams;
};

#ifdef ALPHA_CUTOUT
layout(binding = 0) uniform sampler2D Sampler0;
layout(location = 0) in vec2 texCoord0;
#endif

layout(location = 0) out vec4 fragColor;

void main() {
#ifdef ALPHA_CUTOUT
    if (texture(Sampler0, texCoord0).a < float(ALPHA_CUTOUT)) discard;
#endif

    fragColor = vec4(0.0, 0.0, 0.0, 1.0);
}