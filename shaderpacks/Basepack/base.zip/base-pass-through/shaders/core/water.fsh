#version 450 core

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chunksection.glsl>
#moj_import <minecraft:projection.glsl>

layout(binding = 0) uniform sampler2D Sampler0;
layout(binding = 3) uniform sampler2D Sampler3;
layout(binding = 5) uniform sampler2D Sampler5;

layout(std140, binding = 1) uniform WaveUniforms {
    vec4 WaveData;
};

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) in vec3 worldPos;
layout(location = 5) in vec3 viewPos;
layout(location = 6) in vec3 waveNormal;
layout(location = 7) flat in float isWaterVertex;
layout(location = 8) in vec2 worldXZ;

layout(location = 0) out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor;
    color = mix(vec4(FogColor.rgb, color.a), color, ChunkVisibility);

#ifdef ALPHA_CUTOUT
    if (color.a < float(ALPHA_CUTOUT)) discard;
#endif

    fragColor = apply_fog(color,
        sphericalVertexDistance, cylindricalVertexDistance,
        FogEnvironmentalStart, FogEnvironmentalEnd,
        FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}