#version 450 core

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

layout(binding = 0) uniform sampler2D Sampler0;
layout(binding = 4) uniform sampler2D Sampler4;
layout(binding = 6) uniform sampler2D Sampler6;
layout(binding = 7) uniform sampler2D Sampler7;
layout(binding = 9) uniform sampler2D Sampler9;

#ifdef DISSOLVE
layout(binding = 2) uniform sampler2D DissolveMaskSampler;
#endif

layout(std140, binding = 1) uniform TerrainShadowSplits {
    mat4 ShadowProjViewMat[4];
    vec4 ShadowSplitParams[4];
    vec4 ShadowSunDir;
    vec4 ShadowParams;
};

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
layout(location = 2) in vec4 vertexPerFaceColorBack;
layout(location = 3) in vec4 vertexPerFaceColorFront;
#else
layout(location = 2) in vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) in vec4 overlayColor;
#endif

layout(location = 6) in vec2 texCoord0;
layout(location = 7) in vec3 receiverPos;

layout(location = 0) out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);

#ifdef ALPHA_CUTOUT
    if (color.a < float(ALPHA_CUTOUT)) discard;
#endif

#ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
#else
    vec4 faceVertexColor = vertexColor;
#endif

#ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) discard;
    faceVertexColor.a = 1.0;
#endif

    color *= faceVertexColor * ColorModulator;

#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif

#ifndef EMISSIVE
    color *= lightMapColor;
#endif

    fragColor = apply_fog(color,
        sphericalVertexDistance, cylindricalVertexDistance,
        FogEnvironmentalStart, FogEnvironmentalEnd,
        FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}