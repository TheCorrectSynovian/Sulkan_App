#version 450 core

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chunksection.glsl>

layout(binding = 0) uniform sampler2D Sampler0;
layout(binding = 4) uniform sampler2D Sampler4;
layout(binding = 6) uniform sampler2D Sampler6;
layout(binding = 7) uniform sampler2D Sampler7;
layout(binding = 8) uniform sampler2D Sampler8;
layout(binding = 9) uniform sampler2D Sampler9;

layout(std140, binding = 1) uniform TerrainShadowSplits {
    mat4 ShadowProjViewMat[4];
    vec4 ShadowSplitParams[4];
    vec4 ShadowSunDir;
    vec4 ShadowParams;
};

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) in vec3 receiverPos;

layout(location = 0) out vec4 fragColor;

vec4 sampleNearest(sampler2D src, vec2 uv, vec2 px, vec2 du, vec2 dv) {
    vec2 footprint = sqrt(du * du + dv * dv);
    vec2 texel = uv / px;
    vec2 center = round(texel) - 0.5;
    vec2 offset = clamp((texel - center - 0.5) * px / footprint + 0.5, 0.0, 1.0);
    return textureGrad(src, (center + offset) * px, du, dv);
}

vec4 sampleRGSS(sampler2D src, vec2 uv, vec2 px) {
    vec2 du = dFdxCoarse(uv);
    vec2 dv = dFdyCoarse(uv);

    vec2 footprint = sqrt(du * du + dv * dv);
    float minPx = min(px.x, px.y);
    float blend = smoothstep(minPx, minPx * 2.0, max(footprint.x, footprint.y));

    float lenDu = length(du);
    float lenDv = length(dv);
    float mipExact = max(0.0, log2(sqrt(min(lenDu, lenDv) * max(lenDu, lenDv)) / minPx));
    float mipLo = floor(mipExact);
    float mipBlend = fract(mipExact);

    const vec2 offsets[4] = vec2[4](
        vec2(0.125, 0.375), vec2(-0.125, -0.375),
        vec2(0.375, -0.125), vec2(-0.375, 0.125)
    );

    vec4 lo = vec4(0.0);
    vec4 hi = vec4(0.0);
    for (int i = 0; i < 4; ++i) {
        lo += textureLod(src, uv + offsets[i] * px, mipLo);
        hi += textureLod(src, uv + offsets[i] * px, mipLo + 1.0);
    }

    vec4 smoothSample = mix(lo, hi, mipBlend) * 0.25;
    vec4 sharpSample = sampleNearest(src, uv, px, du, dv);
    return mix(sharpSample, smoothSample, blend);
}

vec4 sampleTerrainTexture(sampler2D src, vec2 uv) {
    vec2 px = 1.0 / TextureSize;
    if (UseRgss == 1) return sampleRGSS(src, uv, px);
    return sampleNearest(src, uv, px, dFdxCoarse(uv), dFdyCoarse(uv));
}

void main() {
    vec4 color = sampleTerrainTexture(Sampler0, texCoord0) * vertexColor;
    color = mix(FogColor * vec4(1.0, 1.0, 1.0, color.a), color, ChunkVisibility);

#ifdef ALPHA_CUTOUT
    if (color.a < float(ALPHA_CUTOUT)) discard;
#endif

    fragColor = apply_fog(color,
        sphericalVertexDistance, cylindricalVertexDistance,
        FogEnvironmentalStart, FogEnvironmentalEnd,
        FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}